// Classes/Controller/DeinController.php

<?php
namespace kupix\qpxviewhelper\Controller;

class DeinController extends \TYPO3\CMS\Backend\Controller\BackendController {

    public function __construct() {

        parent::__construct();
        $path = \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('deineextension');

        $this->addCssFile('main', $path.'/Resources/Public/t3Backend/Css/main.css');

        $this->addJavascriptFile($path.'/Resources/Public/t3Backend/JavaScript/load.js');
        $this->addJavascriptFile($path.'/Resources/Public/t3Backend/JavaScript/bemain.js');
    }
}


//ext_tables.php

<?php
defined('TYPO3_MODE') || die();

call_user_func(function() {
    $_CLASSNAME = 'DeinClassName';

    // BackendLayout
    if (TYPO3_MODE === 'BE' || TYPO3_MODE === 'FE' && isset($GLOBALS['BE_USER'])) {
        // add CSS and JS in TYPO3-BE
        $GLOBALS['TYPO3_CONF_VARS']['SYS']['Objects']['TYPO3\CMS\Backend\Controller\BackendController'] = array(
            'className' => "DeinVendor\\{$_CLASSNAME}\Controller\DeinController"
        );
    }
});
