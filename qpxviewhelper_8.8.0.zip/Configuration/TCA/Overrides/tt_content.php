<?php
$GLOBALS['TCA']['tt_content']['columns']['header']['config']['type'] = 'text';
$GLOBALS['TCA']['tt_content']['columns']['header']['config']['rows'] = '2';
$GLOBALS['TCA']['tt_content']['columns']['header']['config']['cols'] = '60';

$GLOBALS['TCA']['tt_content']['columns']['subheader']['config']['type'] = 'text';
$GLOBALS['TCA']['tt_content']['columns']['subheader']['config']['rows'] = '2';
$GLOBALS['TCA']['tt_content']['columns']['subheader']['config']['cols'] = '60';

$GLOBALS['TCA']['tt_content']['columns']['imageheight']['config']['range']['upper'] = 2000;
$GLOBALS['TCA']['tt_content']['columns']['imagewidth']['config']['range']['upper'] = 2000;

// das TEXTAREA-Feld für HTML-Code von 68 auf 120 Cols verbreitern:
$GLOBALS['TCA']['tt_content']['columns']['bodytext']['config']['cols'] = 120;
$GLOBALS['TCA']['tt_content']['columns']['bodytext']['config']['rows'] = 10;

// Dateiuploads als Slider darstellen:
$GLOBALS['TCA']['tt_content']['columns']['uploads_type']['config']['items']['3']['0'] = 'Bilddateien als Slider ausgeben';
$GLOBALS['TCA']['tt_content']['columns']['uploads_type']['config']['items']['3']['1'] = '3';

//Seiten: title und subtitle
$GLOBALS['TCA']['pages']['columns']['title']['config']['type'] = 'text';
$GLOBALS['TCA']['pages']['columns']['title']['config']['rows'] = '2';
$GLOBALS['TCA']['pages']['columns']['title']['config']['cols'] = '60';

$GLOBALS['TCA']['pages']['columns']['subtitle']['config']['type'] = 'text';
$GLOBALS['TCA']['pages']['columns']['subtitle']['config']['rows'] = '2';
$GLOBALS['TCA']['pages']['columns']['subtitle']['config']['cols'] = '60';

//$languagePath_be = 'LLL:EXT:qpxviewhelper/Resources/Private/Language/locallang_be.xlf:';

$extraContentColumns = array(
    'header_style' => array(
        'exclude' => 1,
        'label' => 'LLL:EXT:qpxviewhelper/Resources/Private/Language/locallang_be.xlf:header_style',
        'config' => array(
            'type' => 'select',
            'renderType' => 'selectSingle',
            'items' => array(
                array(
                    'LLL:EXT:qpxviewhelper/Resources/Private/Language/locallang_be.xlf:header_style.0',
                    '0'
                ),
                array(
                    'LLL:EXT:qpxviewhelper/Resources/Private/Language/locallang_be.xlf:header_style.1',
                    '1'
                ),
                array(
                    'LLL:EXT:qpxviewhelper/Resources/Private/Language/locallang_be.xlf:header_style.2',
                    '2'
                ),
                array(
                    'LLL:EXT:qpxviewhelper/Resources/Private/Language/locallang_be.xlf:header_style.3',
                    '3'
                ),
            ),
            'size' => 1,
            'maxitems' => 1,
            'default' => '',
        )
    ),


);
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns(
        'tt_content',
        $extraContentColumns
);
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addFieldsToPalette(
        'tt_content',
        'header',
        'header_style',
        'after:header_layout'
);
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addFieldsToPalette(
        'tt_content',
        'headers',
        'header_style',
        'after:header_layout'
);

?>
